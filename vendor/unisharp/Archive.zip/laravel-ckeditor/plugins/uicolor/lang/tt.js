﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","tt",{title:"Интерфейс төсләрен сайлау",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Баштан билгеләнгән төсләр җыелмасы",config:"Бу юлны config.js файлына языгыз"});